import tkinter as tk
from time import sleep

loop = 0
root = tk.Tk()
root.geometry("1000x806")
root.configure(bg = "#ff9494")
root.resizable(False, False)
if loop == 1:
    sleep(2)





class sign_in_ui():
    in_root = True
    
    
    canvas = tk.Canvas(root,bg = "#ff9494",height = 806,width = 1000,bd = 0,highlightthickness = 0,relief = "ridge")
    canvas.place(x = 0, y = 0)
    
    
    
    img0 = tk.PhotoImage(file = f"Data/sign_in/img0.png")
    b0 = tk.Button(image = img0,borderwidth = 0,highlightthickness = 0,command=lambda: sign_in_ui.transition("1000x806", "442x806"),relief = "flat")
    
    img1 = tk.PhotoImage(file = f"Data/sign_in/img1.png")
    b1 = tk.Button(image = img1,borderwidth = 0,highlightthickness = 0,state="normal",relief = "flat")
       
    img2 = tk.PhotoImage(file = f"Data/sign_in/img2.png")
    b2 = tk.Button(image = img2,borderwidth = 0,highlightthickness = 0,state="normal",relief = "ridge")
          
    Entry0_img = tk.PhotoImage(file = f"Data/sign_in/img_textBox0.png")
    Entry0_bg = canvas.create_image(499.5, 439.5,image = Entry0_img)
    Entry0 = tk.Entry( bd = 0,bg = "#FFD1D1",highlightthickness = 0)
    
    Entry1_img = tk.PhotoImage(file = f"Data/sign_in/img_textBox1.png")
    Entry1_bg = canvas.create_image(511.5, 204.5,image = Entry1_img)
    Entry1 = tk.Entry(bd = 0,bg = "#FFD1D1",highlightthickness = 0)


    def transition(passthrough1, passthrough2):
        sign_in_ui.remove()
        sign_in_ui.in_root = False
        window_size = update_root_size(root)
        window_size.update_size_x(passthrough1, passthrough2)
        
    def add():
        

        sign_in_ui.b0.place(x = 384, y = 566,width = 231,height = 223)   
        sign_in_ui.Entry0.place(x = 274, y = 413,width = 451,height = 51)     
        sign_in_ui.b1.place(x = 365, y = 307,width = 269,height = 65)
        sign_in_ui.Entry1.place(x = 286, y = 178,width = 441,height = 41)
        sign_in_ui.b2.place(x = 365, y = 72,width = 269,height = 65)

        
        
    def remove():
        sign_in_ui.b0.destroy()
        sign_in_ui.Entry0.destroy()   
        sign_in_ui.b1.destroy()
        sign_in_ui.Entry1.destroy()
        sign_in_ui.b2.destroy()
        sign_in_ui.canvas.delete("all")

class update_root_size(tk.Label):
    def __init__(self, *args, **kwargs):
        tk.Label.__init__(self, *args, **kwargs, bg='#FF9494')
        self._count = 0

    def update_size_x(self, old_size, new_size):

        
        old_num =  old_size.split('x')
        old_x = int(old_num[0])
        old_y = int(old_num[1])
        
        new_num = new_size.split('x')
        new_x = int(new_num[0])
        new_y = int(new_num[1])
        
        global sign_in
        
        if old_x > new_x:
            root.geometry(f"{old_x}x{old_y}")
            old_x = old_x - 2
            current_size = f"{old_x}x{old_y}"
            self.after(2, lambda: self.update_size_x(current_size, new_size))
            
    def update_size_y(self, old_size, new_size):
        old_num =  old_size.split('x')
        old_x = int(old_num[0])
        old_y = int(old_num[1])
        
        new_num = new_size.split('x')
        new_x = int(new_num[0])
        new_y = int(new_num[1])
        
        global sign_in
        
        if old_y > new_y:
            root.geometry(f"{old_x}x{old_y}")
            old_y = old_y - 2
            current_size = f"{old_x}x{old_y}"
            self.after(2, lambda: self.update_size_y(current_size, new_size))
   







size = update_root_size(root)
size.grid(row=900, column=900)
sign_in_ui.add()


root.mainloop()
